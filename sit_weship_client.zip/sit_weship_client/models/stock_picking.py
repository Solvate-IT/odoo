# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#
#    Copyright (C) Solvate Informationstechnologie GmbH
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import models, fields, api, _
import logging
from odoo import tools
import time
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from odoo.exceptions import Warning
from ..weshiperp_osv import Weship

_logger = logging.getLogger(__name__)


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def _create_backorder(self):
        if self.env.context.get('weship_action_done', False):
            return True
        return super(StockPicking, self)._create_backorder()

    @api.model
    def create(self, vals):
        ret_val = super(StockPicking, self).create(vals)
        if not ret_val.partner_id and ret_val.picking_type_id.code == 'internal':
            if ret_val.location_id and ret_val.location_id.partner_id:
                ret_val.partner_id = ret_val.location_id.partner_id.id
            elif ret_val.location_dest_id and ret_val.location_dest_id.partner_id:
                ret_val.partner_id = ret_val.location_dest_id.partner_id.id
        return ret_val

    def remove_weship_link(self):
        for rec in self:
            rec.weship_id = False
            for move in rec.move_lines:
                move.weship_ids.unlink()
        return True

    @api.depends('move_type', 'move_lines.state', 'move_lines.picking_id', 'weship_id', 'is_weship_error')
    def _compute_state(self):
        ''' State of a picking depends on the state of its related stock.move
        - Draft: only used for "planned pickings"
        - Waiting: if the picking is not ready to be sent so if
          - (a) no quantity could be reserved at all or if
          - (b) some quantities could be reserved and the shipping policy is "deliver all at once"
        - Waiting another move: if the picking is waiting for another move
        - Ready: if the picking is ready to be sent so if:
          - (a) all quantities are reserved or if
          - (b) some quantities could be reserved and the shipping policy is "as soon as possible"
        - Done: if the picking is done.
        - Cancelled: if the picking is cancelled
        '''
        for picking in self:
            if not picking.move_lines:
                picking.state = 'draft'
            elif any(move.state == 'draft' for move in picking.move_lines):  # TDE FIXME: should be all ?
                picking.state = 'draft'
            elif all(move.state == 'cancel' for move in picking.move_lines):
                picking.state = 'cancel'
            elif all(move.state in ['cancel', 'done'] for move in picking.move_lines):
                picking.state = 'done'
            else:
                relevant_move_state = picking.move_lines._get_relevant_state_among_moves()
                if relevant_move_state == 'partially_available':
                    picking.state = 'assigned'
                else:
                    picking.state = relevant_move_state
            if picking.state in ['assigned', 'confirmed'] and picking.weship_id:
                picking.state = 'sent_weship'
            if picking.state in ['assigned', 'confirmed'] and not picking.weship_id and picking.is_weship_error:
                picking.state = 'sent_weship_failed'

    @api.depends('state', 'is_locked')
    def _compute_show_validate(self):
        for picking in self:
            if self._context.get('planned_picking') and picking.state == 'draft':
                picking.show_validate = False
            elif picking.state not in (
            'draft', 'confirmed', 'assigned', 'sent_weship', 'sent_weship_failed') or not picking.is_locked:
                picking.show_validate = False
            else:
                picking.show_validate = True

    @api.depends('weship_tracking_ids', 'weship_tracking_ids.is_delivered', 'weship_id', 'weship_tracking_ids.url')
    def get_is_delivered(self):
        for picking in self:
            picking.is_delivered = False
            for tracking in picking.weship_tracking_ids:
                if tracking.is_delivered or tracking.url:
                    picking.is_delivered = True
                    break
        return True

    @api.onchange('picking_type_id', 'partner_id')
    def onchange_picking_type(self):
        location_dest_id = False
        if self.is_fulfillment_location:
            location_dest_id = self.location_dest_id and self.location_dest_id.id or False
        ret_val = super(StockPicking, self).onchange_picking_type()
        if location_dest_id:
            self.location_dest_id = location_dest_id
        return ret_val

    def get_is_weship_warehouse(self):
        for rec in self:
            rec.is_weship_warehouse = rec.picking_type_id and rec.picking_type_id.warehouse_id and \
                                      rec.picking_type_id.warehouse_id.weship_warehouse or False
        return True

    weship_id = fields.Integer('WeShip ID', copy=False)
    weship_error = fields.Text('WeShip Export Error', copy=False)
    is_weship_error = fields.Boolean('Is Weship Error', copy=False)
    is_fulfillment_location = fields.Boolean('Fulfillment Location', related='location_dest_id.is_fulfillment_location')
    no_carrier_available = fields.Boolean('No Carrier Available')
    is_weship_warehouse = fields.Boolean('WeShip Warehouse', compute='get_is_weship_warehouse')

    state = fields.Selection(selection_add=[
        ('sent_weship', 'Sent to WeShip'),
        ('sent_weship_failed', 'Sent to WeShip Failed'),
    ], string='Status', compute='_compute_state',
        copy=False, index=True, readonly=True, store=True, track_visibility='onchange',
        help=" * Draft: not confirmed yet and will not be scheduled until confirmed.\n"
             " * Waiting Another Operation: waiting for another move to proceed before it becomes automatically available (e.g. in Make-To-Order flows).\n"
             " * Waiting: if it is not ready to be sent because the required products could not be reserved.\n"
             " * Ready: products are reserved and ready to be sent. If the shipping policy is 'As soon as possible' this happens as soon as anything is reserved.\n"
             " * Sent to WeShip: Sent shipment to weship to process.\n"
             " * Done: has been processed, can't be modified or cancelled anymore.\n"
             " * Cancelled: has been cancelled, can't be confirmed anymore.")
    show_validate = fields.Boolean(compute='_compute_show_validate',
                                   help='Technical field used to compute whether the validate should be shown.')
    is_delivered = fields.Boolean('Delivered', compute='get_is_delivered', store=True)
    weship_tracking_ids = fields.One2many('weship.picking.tracking', 'picking_id', 'Weship Tracking')

    def update_partner_on_weShip(self):
        for rec in self:
            warehouse_rec = rec.picking_type_id and rec.picking_type_id.warehouse_id or False
            if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                        usr=warehouse_rec.weship_api_login, passwd=warehouse_rec.weship_api_password)
                picking_response = weship_api_obj.call('READ_ONE', 'stock.picking', rec.weship_id)
                partner_email = rec.partner_id.email or rec.partner_id.parent_id and rec.partner_id.parent_id.email or ''
                partner_vals = {
                    'name': rec.partner_id.name or '',
                    'street': rec.partner_id.street or '',
                    'street2': rec.partner_id.street2 or '',
                    'city': rec.partner_id.city or '',
                    'state_id': rec.partner_id.state_id and rec.partner_id.state_id.with_context(
                        {'lang': 'en_US'}).code or '',
                    'country_id': rec.partner_id.country_id and rec.partner_id.country_id.with_context(
                        {'lang': 'en_US'}).code or '',
                    'zip': rec.partner_id.zip or '',
                    'website': rec.partner_id.website or '',
                    'phone': rec.partner_id.phone or '',
                    'mobile': rec.partner_id.mobile or '',
                    'email': partner_email,
                    'comment': rec.partner_id.comment or '',
                    'customer': True,
                    'supplier': True,
                    'ref': rec.partner_id.ref or ''
                }
                if picking_response.get('partner_id', False) and picking_response['partner_id'].get('id', False):
                    partner_response = weship_api_obj.call('UPDATE', 'res.partner',
                                                           picking_response['partner_id'].get('id', False),
                                                           partner_vals)
                    _logger.info("Partner %s related to picking %s is updated on weship." % (
                    rec.partner_id.name or '', rec.name or ''))
                else:
                    partner_response = weship_api_obj.call('CREATE', 'res.partner', partner_vals)
                    if partner_response.get('id', False):
                        weship_partner_id = partner_response.get('id', False)
                        picking_response = weship_api_obj.call('UPDATE', 'stock.picking', rec.weship_id,
                                                               {'partner_id': weship_partner_id})
                        _logger.info(
                            "Partner %s related to picking %s is created on weship and attached with picking." % (
                            rec.partner_id.name or '', rec.name or ''))
        return True

    def create_picking_on_weship(self):
        for rec in self:
            if rec.picking_type_id and rec.picking_type_id.code in ['incoming', 'outgoing', 'internal']:
                warehouse_rec = rec.picking_type_id and rec.picking_type_id.warehouse_id or False
                if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                    weship_error = ''
                    weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                            usr=warehouse_rec.weship_api_login,
                                            passwd=warehouse_rec.weship_api_password)

                    # Validation Meta Data
                    if not warehouse_rec.weship_company_id or not warehouse_rec.weship_out_type_id or not warehouse_rec.weship_in_type_id \
                            or not warehouse_rec.weship_wh_input_stock_loc_id or not warehouse_rec.weship_wh_output_stock_loc_id \
                            or not warehouse_rec.weship_lot_stock_id:
                        rec.write({'weship_id': False, 'is_weship_error': True})
                        self._cr.commit()
                        raise Warning(_('Meta Data is not Loaded for Warehouse : %s' % (warehouse_rec.name)))

                    # Validation Products
                    for move_rec in rec.move_lines:
                        if move_rec.product_id and not move_rec.product_id.weship_id:
                            rec.write({'weship_id': False, 'is_weship_error': True})
                            self._cr.commit()
                            raise Warning(_('Product %s is not exported on WeShip!' % (move_rec.product_id.name)))

                    # Validation Already Created Picking
                    if rec.weship_id:
                        raise Warning(_('Picking %s is already created on WeShip!' % (rec.name)))
                    _logger.info("Picking will be created on WeShip for picking %s." % (rec.name))
                    vals = {'origin': rec.name or '',
                            'client_origin': rec.origin or '',
                            'move_type': rec.move_type or 'direct',
                            'note': rec.note,
                            'min_date': rec.scheduled_date and rec.scheduled_date.strftime('%Y-%m-%d %H:%M:%S') or '',
                            'priority': rec.priority,
                            'company_id': warehouse_rec.weship_company_id}
                    if rec.partner_id:
                        partner_email = rec.partner_id.email or rec.partner_id.parent_id and rec.partner_id.parent_id.email or ''
                        weship_partner_id = False
                        partner_domain = [
                            ('name', '=', rec.partner_id.name or ''),
                            ('street', '=', rec.partner_id.street or ''),
                            ('street2', '=', rec.partner_id.street2 or ''),
                            ('city', '=', rec.partner_id.city or ''),
                            ('zip', '=', rec.partner_id.zip or ''),
                            ('website', '=', rec.partner_id.website or ''),
                            ('phone', '=', rec.partner_id.phone or ''),
                            ('mobile', '=', rec.partner_id.mobile or ''),
                            ('email', '=', partner_email),
                            ('comment', '=', rec.partner_id.comment or ''),
                            ('customer', '=', True),
                            ('supplier', '=', True),
                            ('ref', '=', rec.partner_id.ref or '')
                        ]
                        if rec.partner_id.state_id and rec.partner_id.state_id.code:
                            partner_domain.append(('state_id.code', '=',
                                                   rec.partner_id.state_id and rec.partner_id.state_id.with_context(
                                                       {'lang': 'en_US'}).code or ''))
                        if rec.partner_id.country_id and rec.partner_id.country_id.code:
                            partner_domain.append(('country_id.code', '=',
                                                   rec.partner_id.country_id and rec.partner_id.country_id.with_context(
                                                       {'lang': 'en_US'}).code or ''))

                        _logger.info("Partner %s will be searched on WeShip." % (rec.partner_id.name))
                        response = weship_api_obj.call('READ_FILTERED', 'res.partner',
                                                       {"filters": "%s" % (str(partner_domain))})
                        if response.get('results', []) and response['results'][0].get('id', False):
                            weship_partner_id = response['results'][0].get('id', False)
                            _logger.info("Partner %s found on WeShip with ID : %s." % (
                            rec.partner_id.name, str(weship_partner_id)))
                        else:
                            _logger.info("Partner %s not found on WeShip." % (rec.partner_id.name))
                            _logger.info("Partner %s will be created on WeShip." % (rec.partner_id.name))
                            partner_vals = {
                                'name': rec.partner_id.name or '',
                                'street': rec.partner_id.street or '',
                                'street2': rec.partner_id.street2 or '',
                                'city': rec.partner_id.city or '',
                                'state_id': rec.partner_id.state_id and rec.partner_id.state_id.with_context(
                                    {'lang': 'en_US'}).code or '',
                                'country_id': rec.partner_id.country_id and rec.partner_id.country_id.with_context(
                                    {'lang': 'en_US'}).code or '',
                                'zip': rec.partner_id.zip or '',
                                'website': rec.partner_id.website or '',
                                'phone': rec.partner_id.phone or '',
                                'mobile': rec.partner_id.mobile or '',
                                'email': partner_email,
                                'comment': rec.partner_id.comment or '',
                                'customer': True,
                                'supplier': True,
                                'ref': rec.partner_id.ref or ''
                            }
                            partner_response = weship_api_obj.call('CREATE', 'res.partner', partner_vals)
                            if partner_response.get('error_descrip', False):
                                weship_error += partner_response.get('error_descrip', '') + '\n'
                            if partner_response.get('id', False):
                                _logger.info("Partner %s created on WeShip." % (rec.partner_id.name))
                                weship_partner_id = partner_response.get('id', False)
                        vals.update({'partner_id': weship_partner_id})

                    if rec.picking_type_id and rec.picking_type_id.code == 'incoming':
                        vals.update({'picking_type_id': warehouse_rec.weship_in_type_id,
                                     'location_id': warehouse_rec.weship_wh_input_stock_loc_id,
                                     'location_dest_id': warehouse_rec.weship_lot_stock_id,
                                     'type': 'incoming'})
                    if rec.picking_type_id and rec.picking_type_id.code == 'outgoing':
                        vals.update({'picking_type_id': warehouse_rec.weship_out_type_id,
                                     'location_id': warehouse_rec.weship_lot_stock_id,
                                     'location_dest_id': warehouse_rec.weship_wh_output_stock_loc_id,
                                     'type': 'outgoing'})

                    if rec.picking_type_id and rec.picking_type_id.code == 'internal':
                        if rec.location_id.id == warehouse_rec.lot_stock_id.id:
                            vals.update({'picking_type_id': warehouse_rec.weship_out_type_id,
                                         'location_id': warehouse_rec.weship_lot_stock_id,
                                         'location_dest_id': warehouse_rec.weship_wh_output_stock_loc_id,
                                         'type': 'outgoing'})
                        elif rec.location_dest_id.id == warehouse_rec.lot_stock_id.id:
                            vals.update({'picking_type_id': warehouse_rec.weship_in_type_id,
                                         'location_id': warehouse_rec.weship_wh_input_stock_loc_id,
                                         'location_dest_id': warehouse_rec.weship_lot_stock_id,
                                         'type': 'incoming'})

                    response = weship_api_obj.call('CREATE', 'stock.picking', vals)
                    if response.get('error_descrip', False):
                        weship_error += response.get('error_descrip', '') + '\n'
                    if response.get('id', False):
                        _logger.info("Picking created on WeShip for picking %s." % (rec.name))
                        rec.write({'weship_id': response.get('id', False)})
                        if not rec.move_lines:
                            weship_error += _('No move lines available on picking %s!' % (rec.name)) + '\n'
                        for move in rec.move_lines:
                            _logger.info("Move for product %s will be created on WeShip for picking %s." % (
                            move.product_id.name, rec.name))
                            if not move.product_uom_qty:
                                weship_error += _('Move quantity is zero for product %s of picking %s!' % (
                                move.product_id.name, rec.name)) + '\n'
                                continue
                            move_vals = {
                                'product_uom_qty': move.product_uom_qty or 0.0,
                                'product_uom': move.product_uom and move.product_uom.with_context(
                                    {'lang': 'en_US'}).name or '',
                                'priority': move.priority,
                                'name': move.name or '',
                                'date': move.date and move.date.strftime('%Y-%m-%d %H:%M:%S') or '',
                                'procure_method': move.procure_method or '',
                                'picking_id': response.get('id', False),
                                'date_expected': move.date_expected and move.date_expected.strftime(
                                    '%Y-%m-%d %H:%M:%S') or ''
                            }
                            if move.product_id:
                                if move.product_id.weship_id:
                                    move_vals.update({'product_id': move.product_id.weship_id})
                                    product_response = weship_api_obj.call('READ_ONE', 'product.product',
                                                                           move.product_id.weship_id)
                                    if not product_response.get('id', False):
                                        weship_error += _(
                                            'Product %s is not found on WeShip!' % (move.product_id.name)) + '\n'
                                        continue
                                else:
                                    weship_error += _(
                                        'Product %s is not Exported on WeShip!' % (move.product_id.name)) + '\n'
                                    continue
                            if rec.picking_type_id and rec.picking_type_id.code == 'incoming':
                                move_vals.update({'location_id': warehouse_rec.weship_wh_input_stock_loc_id,
                                                  'location_dest_id': warehouse_rec.weship_lot_stock_id})
                            if rec.picking_type_id and rec.picking_type_id.code == 'outgoing':
                                move_vals.update({'location_id': warehouse_rec.weship_lot_stock_id,
                                                  'location_dest_id': warehouse_rec.weship_wh_output_stock_loc_id})

                            if rec.picking_type_id and rec.picking_type_id.code == 'internal':
                                if rec.location_id.id == warehouse_rec.lot_stock_id.id:
                                    move_vals.update({'location_id': warehouse_rec.weship_lot_stock_id,
                                                      'location_dest_id': warehouse_rec.weship_wh_output_stock_loc_id})
                                elif rec.location_dest_id.id == warehouse_rec.lot_stock_id.id:
                                    move_vals.update({'location_id': warehouse_rec.weship_wh_input_stock_loc_id,
                                                      'location_dest_id': warehouse_rec.weship_lot_stock_id})

                            move_response = weship_api_obj.call('CREATE', 'stock.move', move_vals)
                            if move_response.get('error_descrip', False):
                                weship_error += move_response.get('error_descrip', '') + '\n'
                            if move_response.get('id', False):
                                _logger.info("Move for product %s created on WeShip for picking %s." % (
                                move.product_id.name, rec.name))
                                move.write({'weship_ids': [(0, 0, {'weship_id': move_response.get('id', False)})],
                                            'state': 'assigned'})
                    if weship_error and rec.weship_id:
                        weship_api_obj.call('DELETE', 'stock.picking', rec.weship_id)
                        rec.write({'weship_id': False, 'is_weship_error': True})
                        for stock_move in rec.move_lines:
                            stock_move.weship_ids.unlink()
                        self._cr.commit()
                        raise Warning(weship_error)
                    elif rec.weship_id:
                        rec.write({'weship_error': '', 'is_weship_error': False})
                        weship_api_obj.call('CALL_METHOD', 'stock.picking', rec.weship_id, 'action_confirm', {})
                        weship_api_obj.call('CALL_METHOD', 'stock.picking', rec.weship_id, 'action_assign_from_client',
                                            {})
                        self._cr.commit()
                        for attachment in self.env['ir.attachment'].search(
                                [('res_id', '=', rec.id), ('res_model', '=', 'stock.picking')]):
                            attachment_vals = {
                                'name': attachment.name or '',
                                'datas': attachment.datas.decode("utf-8"),
                                'datas_fname': attachment.datas_fname,
                                'res_model': 'stock.picking',
                                'res_id': rec.weship_id,
                                'type': attachment.type
                            }
                            try:
                                attachment_response = weship_api_obj.call('CREATE', 'ir.attachment', attachment_vals)
                                if attachment_response.get('error_descrip', False):
                                    _logger.info("Attachment %s not created on WeShip for picking %s due to %s" % (
                                    attachment.name, rec.name, attachment_response.get('error_descrip', '')))
                                if attachment_response.get('id', False):
                                    _logger.info(
                                        "Attachment %s created on WeShip for picking %s." % (attachment.name, rec.name))
                            except Exception as e:
                                _logger.info("Attachment %s not created on WeShip for picking %s due to %s" % (
                                attachment.name, rec.name, tools.ustr(e)))
        return True


class stock_picking_type(models.Model):
    _inherit = "stock.picking.type"

    def get_action_picking_tree_failed_weship(self):
        return self._get_action('sit_weship_client.action_picking_failed_weship')

    def _compute_picking_count(self):
        # TDE TODO count picking can be done using previous two
        domains = {
            'count_picking_draft': [('state', '=', 'draft')],
            'count_picking_waiting': [('state', 'in', ('confirmed', 'waiting'))],
            'count_picking_ready': [('state', 'in', ['assigned', 'sent_weship'])],
            'count_picking': [('state', 'in', ('assigned', 'waiting', 'confirmed', 'sent_weship'))],
            'count_picking_late': [('scheduled_date', '<', time.strftime(DEFAULT_SERVER_DATETIME_FORMAT)),
                                   ('state', 'in', ('assigned', 'waiting', 'confirmed', 'sent_weship'))],
            'count_picking_backorders': [('backorder_id', '!=', False),
                                         ('state', 'in', ('confirmed', 'assigned', 'waiting', 'sent_weship'))],
            'count_picking_failed_weship': [('state', 'in', ['sent_weship_failed'])],
        }
        for field in domains:
            data = self.env['stock.picking'].read_group(domains[field] +
                                                        [('state', 'not in', ('done', 'cancel')),
                                                         ('picking_type_id', 'in', self.ids)],
                                                        ['picking_type_id'], ['picking_type_id'])
            count = {
                x['picking_type_id'][0]: x['picking_type_id_count']
                for x in data if x['picking_type_id']
            }
            for record in self:
                record[field] = count.get(record.id, 0)
        for record in self:
            record.rate_picking_late = record.count_picking and record.count_picking_late * 100 / record.count_picking or 0
            record.rate_picking_backorders = record.count_picking and record.count_picking_backorders * 100 / record.count_picking or 0

    count_picking_draft = fields.Integer(compute='_compute_picking_count')
    count_picking_ready = fields.Integer(compute='_compute_picking_count')
    count_picking = fields.Integer(compute='_compute_picking_count')
    count_picking_waiting = fields.Integer(compute='_compute_picking_count')
    count_picking_late = fields.Integer(compute='_compute_picking_count')
    count_picking_failed_weship = fields.Integer(compute='_compute_picking_count')
    count_picking_backorders = fields.Integer(compute='_compute_picking_count')
    rate_picking_late = fields.Integer(compute='_compute_picking_count')
    rate_picking_backorders = fields.Integer(compute='_compute_picking_count')


class WeshipPickingTracking(models.Model):
    _name = 'weship.picking.tracking'

    _description = 'Weship Picking Tracking'

    is_delivered = fields.Boolean('Delivered')
    code = fields.Char('Code', size=128)
    url = fields.Char('URL', size=512)
    name = fields.Text('Details')
    picking_id = fields.Many2one('stock.picking', 'Picking')
