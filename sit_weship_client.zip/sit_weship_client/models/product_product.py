# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#
#    Copyright (C) Solvate Informationstechnologie GmbH
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, fields, models, _
import logging
from odoo import tools
from ..weshiperp_osv import Weship
from odoo.exceptions import Warning

_logger = logging.getLogger(__name__)


class Product(models.Model):
    _inherit = 'product.product'

    weship_id = fields.Integer('WeShip ID')
    quantity = fields.Float('Quantity')
    deactive_at_weship = fields.Boolean('Deactive at WeShip')

    def unlink_product_weship(self):
        for rec in self:
            if rec.company_id:
                warehouse_recs = self.env['stock.warehouse'].search(
                    [('company_id', '=', rec.company_id.id), ('weship_warehouse', '=', True)])
                if warehouse_recs:
                    warehouse_rec = warehouse_recs[0]
                    if warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                        weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                                usr=warehouse_rec.weship_api_login,
                                                passwd=warehouse_rec.weship_api_password)
                        response = weship_api_obj.call('DELETE', 'product.product', rec.weship_id)
                        if response.get('id', False) and response.get('id', False) == rec.weship_id:
                            _logger.info(
                                "Product %s with WeShip ID %s is removed at WeShip." % (rec.name, str(rec.weship_id)))
                            rec.weship_id = 0
                            rec.quantity = 0.0
                            warehouse_rec.write({'weship_product_ids': [(3, rec.id)]})
                        else:
                            response = weship_api_obj.call('UPDATE', 'product.product', rec.weship_id,
                                                           {'active': False})
                            if response.get('id', False) and response.get('id', False) == rec.weship_id:
                                _logger.info("Product %s with WeShip ID %s is archived at WeShip." % (
                                    rec.name, str(rec.weship_id)))
                                rec.deactive_at_weship = True
                                warehouse_rec.write({'weship_product_ids': [(3, rec.id)]})
                    else:
                        raise Warning(
                            _("Product %s can not be deleted due to wrong warehouse configuration.") % (rec.name))
                else:
                    raise Warning(
                        _("Product %s can not be deleted due to no WeShip warehouse related to product company.") % (
                            rec.name))
            else:
                raise Warning(_("Product %s can not be deleted due to no company defined inside product.") % (rec.name))
        return True
