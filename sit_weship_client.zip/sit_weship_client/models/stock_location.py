# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#
#    Copyright (C) Solvate Informationstechnologie GmbH
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import models, fields, api, _
import logging
from odoo import tools
from ..weshiperp_osv import Weship
from odoo.exceptions import Warning

_logger = logging.getLogger(__name__)


class StockLocation(models.Model):
    _inherit = "stock.location"

    @api.depends('location_id')
    def _get_related_warehouse_id(self):
        for location in self:
            warehouse_recs = []
            location_rec = location
            while location_rec:
                if location_rec.usage == 'view':
                    warehouse_recs = self.env['stock.warehouse'].search([('view_location_id', '=', location_rec.id)])
                    if warehouse_recs:
                        break
                    else:
                        location_rec = location_rec.location_id
                else:
                    location_rec = location_rec.location_id

            if warehouse_recs:
                location.related_warehouse_id = warehouse_recs[0].id
                if warehouse_recs[0].weship_warehouse:
                    location.related_weship_warehouse = True
                else:
                    location.related_weship_warehouse = False
            else:
                location.related_warehouse_id = False
                location.related_weship_warehouse = False
        return True

    related_warehouse_id = fields.Many2one('stock.warehouse', 'Related Warehouse', compute='_get_related_warehouse_id')
    related_weship_warehouse = fields.Boolean('Related WeShip Warehouse', compute='_get_related_warehouse_id')
    is_fulfillment_location = fields.Boolean('Fulfillment Location',
                                             help='If checked, internal picking having this location as destination location will allow to select partner.')
    ignore_weship = fields.Boolean('Ignore Weship',
                                   help='If checked, picking having this location as source location or destination location will not send to weship.')
