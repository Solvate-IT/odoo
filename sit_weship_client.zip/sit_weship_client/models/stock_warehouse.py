# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#
#    Copyright (C) Solvate Informationstechnologie GmbH
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import models, fields, api, _
import logging
from odoo import tools
import time
from ..weshiperp_osv import Weship
from odoo.exceptions import Warning

_logger = logging.getLogger(__name__)


class StockWarehouse(models.Model):
    _inherit = "stock.warehouse"

    @api.depends('weship_product_ids')
    def _get_weship_product_count(self):
        for warehouse in self:
            warehouse.update({
                'weship_product_count': len(set(warehouse.weship_product_ids.ids)),
            })
        return True

    weship_warehouse = fields.Boolean('WeShip Warehouse')
    weship_api_api = fields.Char('WeShip API URL', size=64)
    weship_api_db = fields.Char('WeShip API Database', size=64)
    weship_api_login = fields.Char('WeShip API Login', size=32)
    weship_api_password = fields.Char('WeShip API Password')
    weship_company_id = fields.Integer('Company ID')
    weship_out_type_id = fields.Integer('Out Type ID')
    weship_in_type_id = fields.Integer('In Type ID')
    weship_wh_input_stock_loc_id = fields.Integer('WeShip Input Location')
    weship_wh_output_stock_loc_id = fields.Integer('WeShip Output Location')
    weship_lot_stock_id = fields.Integer('WeShip Location Stock')
    weship_product_ids = fields.Many2many('product.product', 'rel_weship_warehouse_products', 'warehouse_id',
                                          'product_id', 'Products')
    weship_product_count = fields.Integer(string='# of Products', compute='_get_weship_product_count', readonly=True)
    weship_allow_move_update = fields.Boolean('Allow Stock Move Update')
    weship_export_stock = fields.Boolean('Incl. Product Stock Qty',
                                         help='Will also update local On-Hand quantity of this warehouse at weship.')

    def load_meta_data(self):
        for warehouse_rec in self:
            if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                        usr=warehouse_rec.weship_api_login, passwd=warehouse_rec.weship_api_password)
                response = weship_api_obj.call('READ_FILTERED', 'res.company', {})
                if response and response.get('results', []):
                    data = response.get('results', [])[0]
                    vals = {
                        'weship_company_id': data.get('id', False),
                        'weship_out_type_id': data.get('warehouse_id', False) and data['warehouse_id'].get(
                            'out_type_id', False),
                        'weship_in_type_id': data.get('warehouse_id', False) and data['warehouse_id'].get('in_type_id',
                                                                                                          False),
                        'weship_wh_input_stock_loc_id': data.get('warehouse_id', False) and data['warehouse_id'].get(
                            'wh_input_stock_loc_id', False),
                        'weship_wh_output_stock_loc_id': data.get('warehouse_id', False) and data['warehouse_id'].get(
                            'wh_output_stock_loc_id', False),
                        'weship_lot_stock_id': data.get('warehouse_id', False) and data['warehouse_id'].get(
                            'lot_stock_id', False)
                    }
                    warehouse_rec.write(vals)
        return True

    def view_weship_exported_products(self):
        for rec in self:
            return {
                'name': _('Products'),
                'res_model': 'product.product',
                'view_mode': 'tree,form',
                'domain': [('id', 'in', [x.id for x in rec.weship_product_ids])],
                'type': 'ir.actions.act_window',
            }
        return True

    def update_weship_product_stock(self):
        _logger.info("System will now update stock at WeShip.")
        for warehouse_rec in self:
            if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                        usr=warehouse_rec.weship_api_login, passwd=warehouse_rec.weship_api_password)
                if not warehouse_rec.weship_product_ids:
                    raise Warning(_('There is no Products to Export!'))
                weship_inventory_id = False
                weship_inventory_line_ids = []
                for product in warehouse_rec.weship_product_ids:
                    product_response = weship_api_obj.call('READ_ONE', 'product.product', product.weship_id)
                    if product_response.get('id', False):
                        qty_available = product.qty_available
                        if warehouse_rec.lot_stock_id:
                            qty_available = product.with_context(
                                {'location': warehouse_rec.lot_stock_id.id}).qty_available
                        user_company_location_quantity = product_response.get('user_company_location_quantity', 0.0)
                        if user_company_location_quantity is None:
                            user_company_location_quantity = 0.0
                        if qty_available >= 0.0 and qty_available != user_company_location_quantity:
                            if not weship_inventory_id:
                                {'name': warehouse_rec.name + ' - ' + str(time.strftime("%Y-%m-%d")),
                                 'filter': 'partial',
                                 'date': time.strftime("%Y-%m-%d %H:%M:%S")}
                                inventory_vals = {
                                    'name': warehouse_rec.name + ' - ' + str(time.strftime("%Y-%m-%d")),
                                    'filter': 'partial',
                                    'date': time.strftime("%Y-%m-%d %H:%M:%S"),
                                    'location_id': warehouse_rec.weship_lot_stock_id,
                                    'company_id': warehouse_rec.weship_company_id
                                }
                                inventory_response = weship_api_obj.call('CREATE', 'stock.inventory', inventory_vals)
                                if inventory_response.get('error_descrip', False):
                                    raise Warning(inventory_response.get('error_descrip', ''))
                                if inventory_response.get('id', False):
                                    _logger.info("Inventory adjustment record created on WeShip with name %s." % (
                                        inventory_vals.get('name', '')))
                                    weship_inventory_id = inventory_response.get('id', False)
                            inventory_line_vals = {
                                'product_id': product.weship_id,
                                'product_qty': qty_available,
                                'inventory_id': weship_inventory_id,
                                'location_id': warehouse_rec.weship_lot_stock_id,
                                'product_uom_id': product.uom_id.with_context({'lang': 'en_US'}).name
                            }
                            inventory_line_response = weship_api_obj.call('CREATE', 'stock.inventory.line',
                                                                          inventory_line_vals)
                            if inventory_line_response.get('error_descrip', False):
                                _logger.info('Inventory line for product %s is skipped due to %s' % (
                                product.name, inventory_line_response.get('error_descrip', '')))
                            if inventory_line_response.get('id', False):
                                _logger.info("Inventory line created on WeShip for product %s." % (product.name))
                                weship_inventory_line_ids.append(inventory_line_response.get('id', False))
                if weship_inventory_id and not weship_inventory_line_ids:
                    response = weship_api_obj.call('DELETE', 'stock.inventory', weship_inventory_id)
                    if response.get('error_descrip', False):
                        _logger.info('Inventory adjustment record can not delete due to %s' % (
                            response.get('error_descrip', '')))
                    if response.get('id', False):
                        _logger.info(
                            "Inventory adjustment record deleted from WeShip due to no inventory lines available.")
                if weship_inventory_id and weship_inventory_line_ids:
                    weship_api_obj.call('CALL_METHOD', 'stock.inventory', weship_inventory_id, 'prepare_inventory', {})
                    weship_api_obj.call('CALL_METHOD', 'stock.inventory', weship_inventory_id, 'action_done', {})
        return True

    def update_weship_product(self):
        context = (self._context or {})
        for warehouse_rec in self:
            if not warehouse_rec.weship_product_ids:
                raise Warning(_('There is no Products to Export!'))
            for product in warehouse_rec.weship_product_ids:
                if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                    weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                            usr=warehouse_rec.weship_api_login,
                                            passwd=warehouse_rec.weship_api_password)
                    _logger.info("Product %s will be updated on WeShip." % (product.name))
                    product_name = product.with_context({'display_default_code': False, 'lang': 'de_DE'}).name_get()[0][
                        1]
                    vals = {'name': product_name,
                            'list_price': product.list_price or 0.0,
                            'standard_price': product.standard_price or 0.0,
                            'type': product.type or 'product',
                            'sale_ok': True,
                            'purchase_ok': True,
                            'default_code': product.default_code or '',
                            'description_sale': product.description_sale or '',
                            'description_purchase': product.description_purchase or '',
                            'description_picking': product.description_picking or '',
                            'image': product.image_1920 and product.image_1920.decode("utf-8") or '',
                            'company_id': warehouse_rec.weship_company_id or False,
                            'uom_id': product.uom_id and product.uom_id.with_context({'lang': 'en_US'}).name or '',
                            'uom_po_id': product.uom_po_id and product.uom_po_id.with_context(
                                {'lang': 'en_US'}).name or '',
                            'volume': product.volume,
                            'weight': product.weight,
                            'weight_uom': 'kg',
                            'dimensions_uom': 'm'
                            }
                    response = weship_api_obj.call('UPDATE', 'product.product', product.weship_id, vals)
                    _logger.info("Product %s updated on WeShip." % (product.name))
            if warehouse_rec.weship_export_stock:
                warehouse_rec.update_weship_product_stock()
                warehouse_rec.write({'weship_export_stock': False})
        return True

    def get_weship_product_quantity(self):
        context = (self._context or {})
        inventory_obj = self.env['stock.inventory']
        inventory_line_obj = self.env['stock.inventory.line']
        for warehouse_rec in self:
            if not warehouse_rec.weship_product_ids:
                raise Warning(_('There is no Products to Import!'))
            inventory_rec = False
            has_inventory_line = False
            for product in warehouse_rec.weship_product_ids:
                if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                    weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                            usr=warehouse_rec.weship_api_login,
                                            passwd=warehouse_rec.weship_api_password)
                    _logger.info("Quantity will be fetched for product %s from WeShip." % (product.name))
                    response = weship_api_obj.call('READ_ONE', 'product.product', product.weship_id)
                    if response.get('user_company_location_quantity', False):
                        product.write({'quantity': response.get('user_company_location_quantity', 0.0)})
                        _logger.info("Quantity fetched for product %s from WeShip." % (product.name))
                    else:
                        _logger.info("Quantity fails to fetch for product %s from WeShip." % (product.name))
                    has_qty = 'user_company_location_quantity' in response and response.get(
                        'user_company_location_quantity') != None and response.get('user_company_location_quantity',
                                                                                   0.0) >= 0.0
                    if product.type != 'service' and has_qty:
                        if not inventory_rec:
                            inventory_rec = inventory_obj.create(
                                {'name': warehouse_rec.name + ' - ' + str(time.strftime("%Y-%m-%d")),
                                 'date': time.strftime("%Y-%m-%d %H:%M:%S")})
                            inventory_rec.action_start()
                            inventory_rec.line_ids.unlink()
                            _logger.info(
                                "Inventory %s created due to product quantity differs with weship product quantity." % (
                                    inventory_rec.name))
                        inventory_line_rec = inventory_line_obj.create({'product_id': product.id,
                                                                        'product_qty': response.get(
                                                                            'user_company_location_quantity', 0.0),
                                                                        'inventory_id': inventory_rec.id,
                                                                        'location_id': warehouse_rec.lot_stock_id and warehouse_rec.lot_stock_id.id or False,
                                                                        'partner_id': warehouse_rec.partner_id and warehouse_rec.partner_id.id or False,
                                                                        'product_uom_id': product.uom_id.id})

                        if (inventory_line_rec.theoretical_qty or 0.0) == (inventory_line_rec.product_qty or 0.0):
                            inventory_line_rec.unlink()
                        else:
                            has_inventory_line = True
                            inventory_rec.product_ids = [(4, product.id)]
                            if not inventory_rec.location_ids:
                                inventory_rec.location_ids = [(4, warehouse_rec.lot_stock_id.id)]
                            _logger.info(
                                "Product %s added to inventory %s due to quantity (%s) differs with weship product quantity (%s)." % (
                                product.name, inventory_rec.name, str(inventory_line_rec.theoretical_qty),
                                str(response.get('user_company_location_quantity', 0.0))))

            if has_inventory_line and inventory_rec:
                inventory_rec.action_validate()
            if not has_inventory_line and inventory_rec:
                inventory_rec.unlink()
        return True

    @api.model
    def scheduler_update_product_qty_weship(self):
        _logger.info("Scheduler started update product quantity from WeShip.")
        for warehouse_rec in self.search([('weship_warehouse', '=', True)]):
            warehouse_rec.get_weship_product_quantity()
        _logger.info("Scheduler completed update product quantity from WeShip.")
        return True

    @api.model
    def scheduler_create_picking_on_weship(self):
        picking_obj = self.env['stock.picking']
        _logger.info("Scheduler started to create pickings on WeShip.")
        for warehouse_rec in self.search([('weship_warehouse', '=', True)]):
            picking_recs = picking_obj.search([('picking_type_id.warehouse_id', '=', warehouse_rec.id),
                                               ('state', 'in', ['assigned', 'confirmed', 'sent_weship_failed']),
                                               ('picking_type_id.code', 'in', ['incoming', 'outgoing', 'internal'])])
            if picking_recs:
                new_picking_recs = []
                for picking in picking_recs:
                    if picking.location_id and picking.location_id.related_weship_warehouse and not picking.location_id.ignore_weship:
                        new_picking_recs.append(picking)
                    elif picking.location_dest_id and picking.location_dest_id.related_weship_warehouse and not picking.location_dest_id.ignore_weship:
                        new_picking_recs.append(picking)
                picking_recs = [x for x in new_picking_recs if not x.weship_id]
                picking_recs = picking_recs[:10]
                _logger.info(
                    "Scheduler will create %s picking on WeShip." % ([x.id for x in picking_recs if not x.weship_id]))
                for picking in picking_recs:
                    try:
                        picking.create_picking_on_weship()
                    except Exception as e:
                        _logger.info("Picking %s not created on WeShip due to %s." % (picking.name, tools.ustr(e)))
                        picking.weship_error = ("Picking %s not created on WeShip due to %s." % (
                        picking.name, tools.ustr(e))).replace('None.', '')
                        self._cr.commit()
        _logger.info("Scheduler completed to create pickings on WeShip.")
        return True

    @api.model
    def scheduler_create_picking_on_client(self):
        context = (self._context or {})
        picking_obj = self.env['stock.picking']
        move_obj = self.env['stock.move']
        stock_return_picking_obj = self.env['stock.return.picking']
        _logger.info("Scheduler started to create incoming pickings from WeShip.")
        for warehouse_rec in self.search([('weship_warehouse', '=', True)]):
            if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                        usr=warehouse_rec.weship_api_login, passwd=warehouse_rec.weship_api_password)
                picking_recs = picking_obj.search([('picking_type_id.warehouse_id', '=', warehouse_rec.id),
                                                   ('picking_type_id.code', 'in', ['incoming', 'internal']),
                                                   ('weship_id', '!=', False),
                                                   ('weship_id', '!=', 0)])
                available_weship_ids = [x.weship_id for x in picking_recs]
                response = weship_api_obj.call('READ_FILTERED', 'stock.picking', {
                    "filters": "[('location_id.usage','=','customer'),('state','=','done'),('company_id','=',%s),('picking_type_id','=',%s),('id','not in',%s)]" % (
                    str(warehouse_rec.weship_company_id), str(warehouse_rec.weship_in_type_id),
                    str(available_weship_ids))})
                for record in response.get('results', []):
                    _logger.info(
                        "System will create return picking from WeShip with WeShip ID : %d." % (record.get('id', '')))
                    if not record.get('origin_id', False):
                        _logger.info(
                            "Create return picking from WeShip with WeShip ID : %d failed due to no origin on imported picking." % (
                                record.get('id', '')))
                    if record.get('origin_id', False) and not record['origin_id'].get('id'):
                        _logger.info(
                            "Create return picking from WeShip with WeShip ID : %d failed due to no origin on imported picking." % (
                                record.get('id', '')))
                    if record.get('origin_id', False) and record['origin_id'].get('id', False):
                        available_picking_rec = picking_obj.search(
                            [('weship_id', '=', record['origin_id'].get('id', False))], limit=1)
                        if not available_picking_rec:
                            _logger.info(
                                "Create return picking from WeShip with WeShip ID : %d failed due to no delivery order found with weship ID %d." % (
                                record.get('id', ''), record['origin_id'].get('id', '')))
                        elif available_picking_rec and available_picking_rec.state != 'done':
                            _logger.info(
                                "Create return picking from WeShip with WeShip ID : %d failed due to delivery order is not in done state." % (
                                    record.get('id', '')))
                        else:
                            ctx = context.copy()
                            ctx.update({'active_model': 'stock.picking', 'active_id': available_picking_rec.id,
                                        'active_ids': [available_picking_rec.id]})
                            defaut_vals = stock_return_picking_obj.with_context(ctx).default_get(
                                ['product_return_moves', 'move_dest_exists', 'parent_location_id',
                                 'original_location_id', 'location_id'])
                            product_return_moves = []
                            for move_record in record.get('move_lines', []):
                                if move_record.get('origin_returned_move_id', False) and move_record[
                                    'origin_returned_move_id'].get('id', False):
                                    move_rec = move_obj.search([('weship_ids.weship_id', '=',
                                                                 move_record['origin_returned_move_id'].get('id',
                                                                                                            False))],
                                                               limit=1)
                                    if move_rec:
                                        product_return_moves.append((0, 0, {'product_id': move_rec.product_id.id,
                                                                            'quantity': move_record.get(
                                                                                'product_uom_qty', 0.0),
                                                                            'move_id': move_rec.id,
                                                                            'uom_id': move_rec.product_id.uom_id.id}))
                            defaut_vals.update(
                                {'picking_id': available_picking_rec.id, 'product_return_moves': product_return_moves})
                            stock_return_picking_rec = stock_return_picking_obj.create(defaut_vals)
                            stock_return_picking_rec._onchange_picking_id()
                            new_picking_id, picking_type_id = stock_return_picking_rec._create_returns()
                            new_picking_rec = picking_obj.browse(new_picking_id)
                            new_picking_rec.weship_id = record.get('id', False)
                            for new_move in new_picking_rec.move_lines:
                                new_move.quantity_done = new_move.product_uom_qty
                                new_move._action_assign()
                                new_move._action_done()
                                new_move.weship_ids = [
                                    (0, 0, {'weship_id': move_record.get('id', False), 'delivered': True})]
                            _logger.info("Return picking from WeShip with WeShip ID : %d successfully created." % (
                                record.get('id', '')))
        _logger.info("Scheduler completed to create incoming pickings from WeShip.")
        return True

    # TO DO
    @api.model
    def scheduler_get_tracking_weship(self):
        picking_obj = self.env['stock.picking']
        tracking_obj = self.env['weship.picking.tracking']
        _logger.info("Scheduler started to fetch tracking details from WeShip.")
        for warehouse_rec in self.search([('weship_warehouse', '=', True)]):
            if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                        usr=warehouse_rec.weship_api_login, passwd=warehouse_rec.weship_api_password)
                picking_recs = picking_obj.search([('picking_type_id.warehouse_id', '=', warehouse_rec.id),
                                                   ('is_delivered', '=', False),
                                                   ('weship_id', '!=', False),
                                                   ('weship_id', '!=', 0),
                                                   ('state', '!=', 'cancel'),
                                                   ('no_carrier_available', '=', False)])
                for picking in picking_recs:
                    if any(move.origin_returned_move_id for move in picking.move_lines):
                        continue
                    _logger.info("Tracking details for %s picking will be fetched from WeShip." % (picking.name))
                    try:
                        tracking_recs = tracking_obj.search([('picking_id', '=', picking.id)])
                        tracking_recs.unlink()
                        response = weship_api_obj.call('CALL_METHOD', 'stock.picking', picking.weship_id,
                                                       'get_tracking_info', {})
                        picking.weship_id
                        if response.get(str(picking.weship_id), False):
                            for tracking in response.get(str(picking.weship_id), []):
                                tracking_obj.create({'is_delivered': tracking.get('is_delivered', False),
                                                     'code': tracking.get('code', ''),
                                                     'url': tracking.get('url', ''),
                                                     'name': tracking.get('details', ''),
                                                     'picking_id': picking.id})
                        else:
                            picking_response = weship_api_obj.call('CALL_METHOD', 'stock.picking', picking.weship_id,
                                                                   'get_no_carrier_info', {})
                            if picking_response.get(str(picking.weship_id), False):
                                picking.no_carrier_available = True

                    except Exception as e:
                        _logger.info("Tracking details for %s picking fails to fetch from WeShip due to %s." % (
                        picking.name, tools.ustr(e)))
        _logger.info("Scheduler completed to fetch tracking details from WeShip.")
        return True

    @api.model
    def scheduler_get_move_state_move_state_weship(self):
        context = dict(self._context or {})
        picking_obj = self.env['stock.picking']
        move_obj = self.env['stock.move']
        _logger.info("Scheduler started to get move state from WeShip.")

        for warehouse_rec in self.search([('weship_warehouse', '=', True), ('weship_allow_move_update', '=', True)]):
            if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                picking_recs = picking_obj.search([('picking_type_id.warehouse_id', '=', warehouse_rec.id),
                                                   ('state', 'not in', ['draft', 'cancel', 'done']),
                                                   (
                                                   'picking_type_id.code', 'in', ['incoming', 'outgoing', 'internal'])])
                picking_ids = [x.id for x in picking_recs if x.weship_id]
                weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                        usr=warehouse_rec.weship_api_login, passwd=warehouse_rec.weship_api_password)
                for move in move_obj.search(
                        [('picking_id', 'in', picking_ids), ('state', 'not in', ['draft', 'cancel', 'done'])]):
                    weship_move_data = []
                    for weship_rec in move.weship_ids:
                        if not weship_rec.delivered:
                            weship_move_id = weship_rec.weship_id
                            while weship_move_id:
                                response = weship_api_obj.call('READ_FILTERED', 'stock.move', {
                                    "filters": "[('split_from','=',%s)]" % (str(weship_move_id))})
                                if response.get('results', []) and response['results'][0].get('id', False):
                                    weship_move_data.append(
                                        (0, 0, {'weship_id': response['results'][0].get('id', False)}))
                                    weship_move_id = response['results'][0].get('id', False)
                                else:
                                    weship_move_id = False

                    if weship_move_data:
                        move.write({'weship_ids': weship_move_data})

                for move in move_obj.search(
                        [('picking_id', 'in', picking_ids), ('state', 'not in', ['draft', 'cancel', 'done'])]):
                    for weship_rec in move.weship_ids:
                        if not weship_rec.delivered:
                            try:
                                response = weship_api_obj.call('READ_ONE', 'stock.move', weship_rec.weship_id)
                                if response.get('state', '') == 'cancel':
                                    weship_rec.write({'cancelled': True})
                                if response.get('state', '') == 'done':
                                    quantity_done = move.quantity_done or 0.0
                                    product_uom_qty = response.get('product_uom_qty', 0.0) or 0.0
                                    qty_done = quantity_done + product_uom_qty
                                    if qty_done > move.product_uom_qty:
                                        qty_done = move.product_uom_qty
                                    move.write({'quantity_done': qty_done})
                                    weship_rec.write({'delivered': True})
                                if all([x.delivered for x in move.weship_ids]):
                                    if move.state == 'waiting':
                                        move._force_assign()
                                    ctx = context.copy()
                                    ctx.update({'weship_action_done': True})
                                    move.with_context(ctx)._action_done()
                                    _logger.info("Move status updated to done for picking %s and product %s." % (
                                    move.picking_id.name, move.product_id.name))
                                    self._cr.commit()
                                if all([x.cancelled for x in move.weship_ids]):
                                    ctx = context.copy()
                                    ctx.update({'weship_action_cancel': True})
                                    _logger.info("Move status updated to cancel for picking %s and product %s." % (
                                    move.picking_id.name, move.product_id.name))
                                    move.with_context(ctx)._action_cancel()
                            except Exception as e:
                                _logger.info("Move status of picking %s for product %s is not updated due to %s." % (
                                move.picking_id.name, move.product_id.name, tools.ustr(e)))
        _logger.info("Scheduler completed to get move state from WeShip.")
        return True
