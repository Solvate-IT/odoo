# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#
#    Copyright (C) Solvate Informationstechnologie GmbH
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import models, fields, api, _
import logging
from odoo import tools
from ..weshiperp_osv import Weship
from odoo.exceptions import Warning

_logger = logging.getLogger(__name__)


class StockMoveWeship(models.Model):
    _name = 'stock.move.weship'

    _description = 'Stock Move Weship'

    weship_id = fields.Integer('WeShip ID')
    delivered = fields.Boolean('Delivered')
    cancelled = fields.Boolean('Cancelled')
    move_id = fields.Many2one('stock.move', 'Stock Move')


class StockMove(models.Model):
    _inherit = 'stock.move'

    weship_ids = fields.One2many('stock.move.weship', 'move_id', 'WeShip ID')

    def _action_done(self, cancel_backorder=False):
        context = dict(self._context or {})
        ret_val = super(StockMove, self)._action_done(cancel_backorder=cancel_backorder)
        if not context.get('weship_action_done', False):
            for move in self:
                warehouse_rec = move.picking_id and move.picking_id.picking_type_id and move.picking_id.picking_type_id.warehouse_id or False
                if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                    weship_error = ''
                    weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                            usr=warehouse_rec.weship_api_login,
                                            passwd=warehouse_rec.weship_api_password)
                    for child_move in move.weship_ids:
                        response = weship_api_obj.call('READ_ONE', 'stock.move', child_move.weship_id)
                        if response.get('state', '') == 'draft':
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id, 'action_confirm', {})
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id, 'force_assign', {})
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id,
                                                'set_operation_done_quantity', {})
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id, 'action_done', {})
                            child_move.delivered = True
                        if response.get('state', '') == 'confirmed':
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id, 'force_assign', {})
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id,
                                                'set_operation_done_quantity', {})
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id, 'action_done', {})
                            child_move.delivered = True
                        if response.get('state', '') == 'assigned':
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id,
                                                'set_operation_done_quantity', {})
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id, 'action_done', {})
                            child_move.delivered = True
        return ret_val

    def _action_cancel(self):
        context = dict(self._context or {})
        ret_val = super(StockMove, self)._action_cancel()
        if not context.get('weship_action_cancel', False):
            for move in self:
                warehouse_rec = move.picking_id and move.picking_id.picking_type_id and move.picking_id.picking_type_id.warehouse_id or False
                if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                    weship_error = ''
                    weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db,
                                            usr=warehouse_rec.weship_api_login,
                                            passwd=warehouse_rec.weship_api_password)
                    for child_move in move.weship_ids:
                        response = weship_api_obj.call('READ_ONE', 'stock.move', child_move.weship_id)
                        if response.get('state', '') == 'done':
                            raise Warning(_(
                                'You can not cancel picking because move with product %s is already validated at WeShip.') % (
                                              move.product_id.name))
                        elif response.get('state', '') == 'cancel':
                            continue
                        else:
                            weship_api_obj.call('CALL_METHOD', 'stock.move', child_move.weship_id, 'action_cancel', {})
                            child_move.cancelled = True
        return ret_val
