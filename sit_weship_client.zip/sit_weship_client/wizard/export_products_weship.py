# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#
#    Copyright (C) Solvate Informationstechnologie GmbH
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import models, fields, api, _
import logging
from odoo import tools
from odoo.exceptions import Warning
from ..weshiperp_osv import Weship

_logger = logging.getLogger(__name__)

class ExportProductsWeship(models.TransientModel):
    
    _name = 'export.products.weship'
    
    _description = 'Export Products'
    
    product_ids = fields.Many2many('product.product', 'rel_export_weship_products', 'export_weship_id', 'product_id', string='Products')
    link_existing = fields.Boolean('Link Existing')
    fail_result = fields.Text('Fail Result')
    has_fail_result = fields.Boolean('Has Fail Result', default=False)
    
    def export_weship_product(self):
        context = (self._context or {})
        warehouse_obj = self.env['stock.warehouse']
        warehouse_rec = False
        if context.get('active_id', False) and context.get('active_model', '') == 'stock.warehouse':
            warehouse_rec = warehouse_obj.browse(context.get('active_id', False))
        if not warehouse_rec:
            raise Warning(_('There is no Active Warehouse!'))
        for rec in self:
            if not rec.product_ids:
                raise Warning(_('There is no Products to Export!'))
            fail_result = ''
            for product in rec.product_ids:
                if warehouse_rec and warehouse_rec.weship_warehouse and warehouse_rec.weship_api_api and warehouse_rec.weship_api_db and warehouse_rec.weship_api_login and warehouse_rec.weship_api_password:
                    weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, db=warehouse_rec.weship_api_db, usr=warehouse_rec.weship_api_login, passwd=warehouse_rec.weship_api_password)
                    _logger.info("Product %s will be created / activated on WeShip" %(product.name))
                    product_name = product.with_context({'display_default_code' : False, 'lang' : 'de_DE'}).name_get()[0][1]
                    vals = {'name' : product_name,
                            'list_price' : product.list_price or 0.0,
                            'standard_price' : product.standard_price or 0.0,
                            'type' : product.type or 'product',
                            'sale_ok' : True,
                            'purchase_ok' : True,
                            'default_code' : product.default_code or '',
                            'description_sale' : product.description_sale or '',
                            'description_purchase' : product.description_purchase or '',
                            'description_picking' : product.description_picking or '',
                            'image' : product.image_1920 and product.image_1920.decode("utf-8") or '',
                            'company_id' : warehouse_rec.weship_company_id or False,
                            'uom_id' : product.uom_id and product.uom_id.with_context({'lang' : 'en_US'}).name or '',
                            'uom_po_id' : product.uom_po_id and product.uom_po_id.with_context({'lang' : 'en_US'}).name or '',
                            'active' : True,
                            'volume': product.volume,
                            'weight': product.weight,
                            'weight_uom': 'kg',
                            'dimensions_uom': 'm'
                            }
                    if product.weship_id:
                        response = weship_api_obj.call('UPDATE', 'product.product', product.weship_id, vals)
                        if response.get('id', False):
                            _logger.info("Product %s activated on WeShip." %(product.name))
                            warehouse_rec.write({'weship_product_ids' : [(4, product.id)]})
                            product.deactive_at_weship = False
                    else:
                        if rec.link_existing:
                            if product.default_code and warehouse_rec.weship_company_id:
                                existing_response = weship_api_obj.call('READ_FILTERED', 'product.product', {"filters" : "[('default_code','=','%s'),('company_id','=',%s)]" %(str(product.default_code or ''), str(warehouse_rec.weship_company_id))})
                                if existing_response.get('results', []) and existing_response['results'][0].get('id', False):
                                    product.write({'weship_id' : existing_response['results'][0].get('id', False)})
                                    warehouse_rec.write({'weship_product_ids' : [(4, product.id)]})
                                else:
                                    if not fail_result:
                                        fail_result += "%s%s%s\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n" % \
                                         (_("Name").ljust(50), _("Internal Reference").ljust(50), _("Fail Reason").ljust(100))
                                    fail_result += "%s%s%s\n" % ((product.name or '').ljust(50), (product.default_code or '').ljust(50), _("Product can not link as its not found on weship !").ljust(100))
                            else:
                                if not fail_result:
                                    fail_result += "%s%s%s\n-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n" % \
                                     (_("Name").ljust(50), _("Internal Reference").ljust(50), _("Fail Reason").ljust(100))
                                if not product.default_code:
                                    fail_result += "%s%s%s\n" % ((product.name or '').ljust(50), (product.default_code or '').ljust(50), _("Product can not link due to empty internal reference !").ljust(100))
                                if not warehouse_rec.weship_company_id:
                                    fail_result += "%s%s%s\n" % ((product.name or '').ljust(50), (product.default_code or '').ljust(50), _("Product can not link due to empty weship company ID inside warehouse !").ljust(100))
                        else:
                            response = weship_api_obj.call('CREATE', 'product.product', vals)
                            if response.get('id', False):
                                _logger.info("Product %s created on WeShip." %(product.name))
                                product.write({'weship_id' : response.get('id', False)})
                                warehouse_rec.write({'weship_product_ids' : [(4, product.id)]})
            if fail_result:
                rec.fail_result = fail_result
                rec.has_fail_result = True
                return {
                    'name': _('Export WeShip Products'),
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'export.products.weship',
                    'res_id': rec.id,
                    'type': 'ir.actions.act_window',
                    'target' : 'new',
                }
        return True
