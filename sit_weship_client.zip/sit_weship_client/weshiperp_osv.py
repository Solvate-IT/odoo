# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#
#    Copyright (C) Solvate Informationstechnologie GmbH
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import csv
import random
import logging
import json
from odoo import tools
import requests

_logger = logging.getLogger(__name__)

headers = {'Content-Type': 'text/html; charset=utf-8'}

"""
==============================================================================================
Example:

filter = {
    "filters": "[('some_field_1', '=', some_value_1), ('some_field_2', '!=', some_value_2), ...]",
    "offset":  XXX,
    "limit":   XXX,
    "order":   "list_of_fields"  # default 'name asc'
}

vals = {'name' : 'xxxxx',
        'date' : 'YYYY',
}

record_id = Record ID of WeShip

=============================================================================================
##############################################################################################

from ..weshiperp_osv import Weship
weship_api_obj = Weship(URL=warehouse_rec.weship_api_api, 
                        db=warehouse_rec.weship_api_db, 
                        usr=warehouse_rec.weship_api_login, 
                        passwd=warehouse_rec.weship_api_password)
                    
CREATE : weship_api_obj.call('CREATE', 'model.name', vals)

UPDATE : weship_api_obj.call('UPDATE', 'model.name', record_id, vals)

READ_ONE : weship_api_obj.call('READ_ONE', 'model.name', record_id)

READ_FILTERED : weship_api_obj.call('READ_FILTERED', 'model.name', filter)

DELETE : weship_api_obj.call('DELETE', 'model.name', record_id)

################################################################################################
"""


class CREATE:

    def __init__(self, model):
        self.model = model

    def post_create_data(self, URL, values):
        API_URL = URL + '/api/' + str(self.model)
        json_data = json.dumps(values)
        response = requests.post(API_URL, data=json_data, headers=headers).text
        return json.loads(response)


class UPDATE:

    def __init__(self, model):
        self.model = model

    def put_update_data(self, URL, record_id, values):
        API_URL = URL + '/api/' + str(self.model) + '/' + str(record_id)
        json_data = json.dumps(values)
        response = requests.put(API_URL, data=json_data, headers=headers).text
        return json.loads(response)


class READ_ONE:

    def __init__(self, model):
        self.model = model

    def get_record_data(self, URL, record_id):
        API_URL = URL + '/api/' + str(self.model) + '/' + str(record_id)
        response = requests.get(API_URL, headers=headers).text
        return json.loads(response)


class READ_FILTERED:

    def __init__(self, model):
        self.model = model

    def get_filtered_data(self, URL, filter):
        API_URL = URL + '/api/' + str(self.model)
        json_data = json.dumps(filter)
        response = requests.get(API_URL, data=json_data, headers=headers).text
        return json.loads(response)


class DELETE:

    def __init__(self, model):
        self.model = model

    def delete_data(self, URL, record_id):
        API_URL = URL + '/api/' + str(self.model) + '/' + str(record_id)
        response = requests.delete(API_URL, headers=headers).text
        return json.loads(response)


class CALL_METHOD:

    def __init__(self, model):
        self.model = model

    def call_model_method(self, URL, record_id, method, values):
        API_URL = URL + '/api/' + str(self.model) + '/' + str(record_id) + '/' + str(method)
        json_data = json.dumps(values)
        response = requests.put(API_URL, data=json_data, headers=headers).text
        return json.loads(response)


class Weship(object):
    ''' Add default login details here if required '''

    passwd = ''
    usr = ''
    db = ''
    URL = ''
    token = ''

    def __init__(self, URL=None, db=None, usr=None, passwd=None):
        if URL != None:
            self.URL = URL
        if db != None:
            self.db = db
        if usr != None:
            self.usr = usr
        if passwd != None:
            self.passwd = passwd
        random.seed()

    def connect(self, URL=None, db=None, usr=None, passwd=None):
        if URL == None:
            URL = self.URL + '/api/auth/get_tokens'
        if db == None:
            db = self.db
        if usr == None:
            usr = self.usr
        if passwd == None:
            passwd = self.passwd

        json_data = json.dumps({'db': db, 'username': usr, 'password': passwd})
        response = requests.post(URL, data=json_data, headers=headers).text
        token_response = json.loads(response)
        self.token = token_response.get('success', False) and token_response.get('data', False) and token_response[
            'data'].get('access_token', '') or ''

    def call(self, method_name, model, *args):
        return_result = {}
        try:
            if method_name == 'CREATE':
                try:
                    self.connect()
                    lo = CREATE(model)
                    headers.update({'access_token': self.token})
                    result = lo.post_create_data(self.URL, args[0])
                    if not result.get('success', False):
                        _logger.error('Failed to create record due to %s - %s !' % (
                        tools.ustr(result.get('error', '')), tools.ustr(result.get('errorMsg', ''))))
                        return_result = result.get('data', {})
                    else:
                        return_result = result.get('data', {})
                    headers.pop('access_token')
                except Exception as e:
                    _logger.error('Failed to create record due to %s !' % (tools.ustr(e)))
                    result = []
            if method_name == 'UPDATE':
                try:
                    self.connect()
                    lo = UPDATE(model)
                    headers.update({'access_token': self.token})
                    result = lo.put_update_data(self.URL, args[0], args[1])
                    if not result.get('success', False):
                        _logger.error('Failed to update record due to %s - %s !' % (
                        tools.ustr(result.get('error', '')), tools.ustr(result.get('errorMsg', ''))))
                        return_result = result.get('data', {})
                    else:
                        return_result = result.get('data', {})
                    headers.pop('access_token')
                except Exception as e:
                    _logger.error('Failed to update record due to %s !' % (tools.ustr(e)))
                    result = []
            if method_name == 'READ_ONE':
                try:
                    self.connect()
                    lo = READ_ONE(model)
                    headers.update({'access_token': self.token})
                    result = lo.get_record_data(self.URL, args[0])
                    if not result.get('success', False):
                        _logger.error('Failed to read one record due to %s - %s !' % (
                        tools.ustr(result.get('error', '')), tools.ustr(result.get('errorMsg', ''))))
                        return_result = result.get('data', {})
                    else:
                        return_result = result.get('data', {})
                    headers.pop('access_token')
                except Exception as e:
                    _logger.error('Failed to read one record due to %s !' % (tools.ustr(e)))
                    result = []
            if method_name == 'READ_FILTERED':
                try:
                    self.connect()
                    lo = READ_FILTERED(model)
                    headers.update({'access_token': self.token})
                    result = lo.get_filtered_data(self.URL, args[0])
                    if not result.get('success', False):
                        _logger.error('Failed to read filtered records due to %s - %s !' % (
                        tools.ustr(result.get('error', '')), tools.ustr(result.get('errorMsg', ''))))
                        return_result = result.get('data', {})
                    else:
                        return_result = result.get('data', {})
                    headers.pop('access_token')
                except Exception as e:
                    _logger.error('Failed to read filtered records due to %s !' % (tools.ustr(e)))
                    result = []
            if method_name == 'DELETE':
                try:
                    self.connect()
                    lo = DELETE(model)
                    headers.update({'access_token': self.token})
                    result = lo.delete_data(self.URL, args[0])
                    if not result.get('success', False):
                        _logger.error('Failed to delete record due to %s - %s !' % (
                        tools.ustr(result.get('error', '')), tools.ustr(result.get('errorMsg', ''))))
                        return_result = result.get('data', {})
                    else:
                        return_result = result.get('data', {})
                    headers.pop('access_token')
                except Exception as e:
                    _logger.error('Failed to delete record due to %s !' % (tools.ustr(e)))
                    result = []
            if method_name == 'CALL_METHOD':
                try:
                    self.connect()
                    lo = CALL_METHOD(model)
                    headers.update({'access_token': self.token})
                    result = lo.call_model_method(self.URL, args[0], args[1], args[2])
                    if not result.get('success', False):
                        _logger.error('Failed to call method due to %s - %s !' % (
                        tools.ustr(result.get('error', '')), tools.ustr(result.get('errorMsg', ''))))
                        return_result = json.loads(result.get('data', '{}'))
                    else:
                        return_result = json.loads(result.get('data', '{}'))
                    headers.pop('access_token')
                except Exception as e:
                    _logger.error('Failed to call method due to %s !' % (tools.ustr(e)))
                    result = {}
        except Exception as err:
            raise Exception(err.faultString)
            return_result = ''
        return return_result
